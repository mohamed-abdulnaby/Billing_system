import{p as r}from"./HhXf8ogk.js";import{s as t}from"./pt68Pk7D.js";const o={get error(){return r.error},get status(){return r.status}};t.updated.check;export{o as p};
