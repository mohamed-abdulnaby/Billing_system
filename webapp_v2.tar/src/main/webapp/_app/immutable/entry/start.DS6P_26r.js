import{a as r}from"../chunks/pt68Pk7D.js";import{x as t}from"../chunks/HhXf8ogk.js";export{t as load_css,r as start};
